package com.example.final_task;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context mContext;
    private ListView list_memo;
    private MyAdapter<memo>myAdapter=null;
    private List<memo> mData=null;
    private Button addBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_main);
        //toolbar=parentView.findViewById(R.id.toolbar);
        mContext=MainActivity.this;
        init();
    }
    private void init(){
        addBtn=(Button)findViewById(R.id.button1);
        list_memo=(ListView)findViewById(R.id.list_memo);

        //数据初始化
        mData=new ArrayList<memo>();
        mData.add(new memo("测试标题1","备忘录内容1",0));
        mData.add(new memo("测试标题2","备忘录内容2",1));

        myAdapter=new MyAdapter<memo>((ArrayList)mData,R.layout.item) {
            @Override
            public void bindView(MyAdapter.ViewHolder holder, memo obj) {
                holder.setText(R.id.itemTitle,obj.getTitle());
                holder.setText(R.id.itemDate,obj.getDate());
            }
        };
        list_memo.setAdapter(myAdapter);

        //跳转到添加界面
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,edit_memo.class);
                startActivity(intent);
            }
        });


    }
}
